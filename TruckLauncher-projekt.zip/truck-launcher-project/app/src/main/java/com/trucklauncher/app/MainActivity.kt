package com.trucklauncher.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Locale

class MainActivity : Activity() {
    private val blue = Color.rgb(0, 180, 255)
    private val bg = Color.rgb(3, 10, 23)
    private val prefs by lazy { getSharedPreferences("truck", MODE_PRIVATE) }
    private lateinit var speedText: TextView
    private lateinit var timeText: TextView
    private lateinit var statusText: TextView
    private lateinit var photo: ImageView
    private var status = "POSTÓJ"
    private var lastTick = System.currentTimeMillis()
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            val delta = (now - lastTick).coerceIn(0, 5000)
            lastTick = now
            val key = "time_$status"
            prefs.edit().putLong(key, prefs.getLong(key, 0L) + delta).apply()
            updateTime()
            handler.postDelayed(this, 1000)
        }
    }
    private val locationListener = LocationListener { loc ->
        val kmh = (loc.speed * 3.6).coerceAtLeast(0.0)
        speedText.text = "${kmh.toInt()} km/h"
        if (kmh > 5 && status != "JAZDA") setStatus("JAZDA")
        else if (kmh < 2 && status == "JAZDA") setStatus("PRACA")
    }
    private fun border(): GradientDrawable = GradientDrawable().apply {
        setColor(bg); setStroke(2, blue); cornerRadius = 18f
    }
    private fun text(s: String, size: Float = 18f): TextView = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
    }
    private fun tile(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
        background = border(); setPadding(8, 6, 8, 6)
    }
    private fun add(parent: LinearLayout, child: View, weight: Float = 1f) {
        parent.addView(child, LinearLayout.LayoutParams(0, -1, weight).apply { setMargins(4, 4, 4, 4) })
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 12f; isAllCaps = false; setTextColor(Color.WHITE)
        background = border(); setOnClickListener { action() }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.statusBarColor = bg; window.navigationBarColor = bg
        status = prefs.getString("status", "POSTÓJ") ?: "POSTÓJ"
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(6, 6, 6, 6) }
        val title = text("🚛  TRUCK LAUNCHER  •  PANEL KIEROWCY", 19f).apply { setTextColor(blue); setTypeface(null, Typeface.BOLD) }
        root.addView(title, LinearLayout.LayoutParams(-1, 42))
        val top = LinearLayout(this)
        root.addView(top, LinearLayout.LayoutParams(-1, 0, 1f))
        val speedBox = tile()
        speedBox.addView(text("PRĘDKOŚĆ GPS", 13f))
        speedText = text("0 km/h", 30f).apply { setTextColor(blue); setTypeface(null, Typeface.BOLD) }
        speedBox.addView(speedText)
        add(top, speedBox)
        val timeBox = tile()
        timeBox.addView(text("CZAS KIEROWCY", 13f))
        statusText = text(status, 19f).apply { setTextColor(blue) }
        timeText = text("00:00:00", 19f)
        timeBox.addView(statusText); timeBox.addView(timeText)
        val statuses = LinearLayout(this)
        for (s in listOf("JAZDA", "PRACA", "ODPOCZYNEK", "POSTÓJ")) {
            statuses.addView(button(s.take(4)) { setStatus(s) }, LinearLayout.LayoutParams(0, 46, 1f))
        }
        timeBox.addView(statuses)
        add(top, timeBox, 1.5f)
        val bottom = LinearLayout(this)
        root.addView(bottom, LinearLayout.LayoutParams(-1, 0, 1f))
        val imageBox = tile()
        photo = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.rgb(10, 27, 48)) }
        imageBox.addView(photo, LinearLayout.LayoutParams(-1, 0, 1f))
        imageBox.addView(button("🖼 Zmień obrazek") { chooseImage() }, LinearLayout.LayoutParams(-1, 48))
        add(bottom, imageBox)
        val apps = tile()
        apps.addView(button("🗺 MAPY GOOGLE") { launch("com.google.android.apps.maps") }, LinearLayout.LayoutParams(-1, 0, 1f))
        apps.addView(button("🚗 WAZE") { launch("com.waze") }, LinearLayout.LayoutParams(-1, 0, 1f))
        apps.addView(button("🎵 REPLAIO") { launch("com.hv.replaio") }, LinearLayout.LayoutParams(-1, 0, 1f))
        apps.addView(button("⚙ USTAWIENIA") { startActivity(Intent(Settings.ACTION_SETTINGS)) }, LinearLayout.LayoutParams(-1, 0, 1f))
        add(bottom, apps, 1.5f)
        setContentView(root)
        prefs.getString("photo", null)?.let { runCatching { photo.setImageURI(Uri.parse(it)) } }
        updateTime(); handler.post(ticker)
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
        else startGps()
    }
    private fun launch(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Zainstaluj aplikację: $pkg", Toast.LENGTH_LONG).show()
    }
    private fun chooseImage() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "image/*"; addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, 2)
    }
    @Deprecated("Legacy picker for broad Android support")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2 && resultCode == RESULT_OK) data?.data?.let { uri ->
            runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            prefs.edit().putString("photo", uri.toString()).apply()
            photo.setImageURI(uri)
        }
    }
    private fun setStatus(s: String) { status = s; prefs.edit().putString("status", s).apply(); statusText.text = s; updateTime() }
    private fun updateTime() {
        val seconds = prefs.getLong("time_$status", 0L) / 1000
        timeText.text = String.format(Locale.getDefault(), "%02d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
    }
    private fun startGps() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            runCatching { lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locationListener) }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) startGps()
    }
    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        runCatching { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(locationListener) }
        super.onDestroy()
    }
}
