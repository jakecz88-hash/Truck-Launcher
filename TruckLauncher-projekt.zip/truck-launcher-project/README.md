# Truck Launcher — wersja 1.0

Prosty panel kierowcy Android: GPS, czas jazdy/pracy/odpoczynku/postoju, wybór zdjęcia, skróty do Google Maps, Waze i Replaio.

**Ważne:** Mapy Google nie są osadzone wewnątrz panelu. Aby uzyskać widok 70/30, uruchom Mapy Google i Truck Launcher w trybie podzielonego ekranu Androida. Dostępność proporcji zależy od urządzenia. Aplikacja nie włącza automatycznie split-screen.

Waze i Replaio otwierane są jako osobne aplikacje; panel nie odczytuje ich ostrzeżeń ani metadanych odtwarzania. Licznik jest pomocniczy, nie zastępuje tachografu.

## Budowa APK na GitHubie

Prześlij wszystkie pliki i foldery do głównego katalogu repozytorium. W zakładce **Actions** uruchom **Build Android APK** (Run workflow). Po zakończeniu pobierz artefakt **TruckLauncher-APK**. W nim znajdziesz `app-debug.apk` do instalacji na Androidzie.

Projekt jest źródłowy i nie był skompilowany ani przetestowany na fizycznym tablecie w tym środowisku.
